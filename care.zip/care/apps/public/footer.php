<footer>
<div class="footer-main">
    <div class="table">
        <div class="row">
          <div class="cell">
          	<ul>
           	  <li><a href="http://www.carehospitals.com/get-an-appointment">Get an Appointment</a></li>
                            <li><a href="#">Virtual Tour</a></li>
               
              
              <li><a href="http://www.carehospitals.com/care-feedback">Feedback</a></li>
            </ul>
            <ul class="footer-second-menu-padding">
           	                <li><a href="http://www.carehospitals.com/care-privacy-policy">Privacy Policy</a></li>
			                              <li><a href="http://www.carehospitals.com/care-disclaimer">Disclaimer</a></li>
			   
              <li><a href="http://www.carehospitals.com/care-site-map">Site Map</a></li>
            </ul>
          </div>
            <div class="cell">
            	<div class="follow-us-on">
                	<ul>
                    	<li>Follow Us On</li>
                                                <li><a href="https://www.facebook.com/carehospitalsindia" target="_blank"><img src="apps/images/facebook1.png" alt="Facebook" width="24" height="24"></a></li>
                                                <li><a href="https://www.linkedin.com/company/care-quality-care-india-limited" target="_blank"><img src="apps/images/linkedin1.png" alt="Facebook" width="24" height="24"></a></li>
                                                <li><a href="https://www.youtube.com/user/carehospitalsindia" target="_blank"><img src="apps/images/youtube.png" alt="Facebook" width="24" height="24"></a></li>
                                                <li><a href="http://www.carehospitals.com/blog/" target="_blank"><img src="apps/images/blog.png" alt="Facebook" width="24" height="24"></a></li>
                                                <li><a href="https://twitter.com/CARE_Hospitals1" target="_blank"><img src="apps/images/twitter-icon.png" alt="Facebook" width="24" height="24"></a></li>
                                               
                    </ul>
                </div>
          </div>
            <div class="cell footer-align-right">
           	  <div class="copyright">
                	All Rights Reserved © CARE HOSPITALS<br>
                <a href="http://www.eparivartan.com/" target="_blank"><img src="apps/images/parivartan.png" alt="parivartan" width="159" height="11"></a> </div>
            </div>
        </div>
    </div>
</div>
</footer>