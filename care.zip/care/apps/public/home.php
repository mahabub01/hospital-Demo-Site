<div style="width:300px; position:absolute; z-index:025;height:200px; margin-top:80px;">
<div class="temp_lnk1"><a href="http://www.carehospitals.com/get-an-appointment">Get an Appointment</a></div>
<div class="temp_lnk1"><a href="http://www.carehospitals.com/book-a-healthcheckup">Book a Health Check-up</a></div>

<div class="temp_lnk1"><a href="http://www.carehospitals.com/ask_an_estimate">Ask for an Estimate</a></div>
<div class="temp_lnk1"><a href="http://www.carehospitals.com/stent_pricing_NPPA.pdf">Stent Pricing as per NPPA</a></div>

</div>
<div style="width:250px; position:absolute; z-index:030;height:50px; margin-top:300px;">
<div class="temp_lnk1"><a href="http://www.carehospitals.com/ask-for-secondopinion">Cardiac Second Opinion</a></div>
</div>

<div class="container" style="background-color:#eae8dc;">
<!-- Banner Start -->
<div class="container" style="background-color:#eae8dc;">
<!-- Banner Start -->
<div class="banner">
	<div id="care-banner-demo" class="careslider">
    <div class="find-doctot-main">
    	<div class="find-doctor">
        	<h2><img src="Care%20Hospitals%20-%20Multispecialty%20Healthcare%20Centers%20in%20India_files/find-a-doctor-icon2.png" alt="Find a Doctor" title="Find a Doctor" width="19" height="18">Find a Doctor</h2>
            <form name="frmsrch" method="post" action="http://www.carehospitals.com/doctor_search" onsubmit="return doValidate();">
            <div class="items-main">
            <div class="item">
            
            	<select name="sel_branch" id="sel_branch" class="select-box-1" onchange="GetSpecialities(this.value)">
            	 <option value="" selected="selected">Select Hospital</option>
                                      <option value="1">CARE Hospitals, Banjara Hills,  Hyderabad</option>
                                      <option value="2">CARE Outpatient Centre, Banjara Hills, Hyderabad</option>
                                      <option value="4">CARE Hospitals, Nampally, Hyderabad</option>
                                      <option value="5">Guru Nanak CARE Hospitals, Musheerabad, Hyderabad</option>
                                      <option value="6">CARE Hospitals, Market Street, Secunderabad</option>
                                      <option value="19">CARE Hospitals, Hi-tech City, Hyderabad</option>
                                      <option value="7">CARE Hospitals, Ramnagar, Visakhapatnam</option>
                                      <option value="8">CARE Hospitals, Maharanipeta, Visakhapatnam</option>
                                      <option value="16">CARE Hospitals, Railway New Colony, Visakhapatnam</option>
                                      <option value="9">Ramkrishna CARE Hospitals, Raipur</option>
                                      <option value="11"> Aditya CARE Hospitals, Bhubaneswar</option>
                                      <option value="20">CARE Hospitals, Prachi Enclave, Bhubaneswar</option>
                                      <option value="12">CARE Hospitals, Nagpur</option>
                                      <option value="14">Galaxy CARE Hospitals, Pune</option>
                                   </select>
              </div>
              <div class="item">
            	<div id="subcat">
                <select name="speciality" id="speciality" class="select-box-1">
                  <option value="" selected="selected">Select Specialty</option>
                </select>
              </div>
              </div>
              
              <div class="item">
              <input name="txtDoc" id="txtDoc" class="text-field-full" type="text">
              </div>
              <div class="item">
              	<div class="button-3 fl_right">
                <input name="Search" value="Search" class="submitbutton" type="submit">
</div>
              </div>
              
              </div>
            </form>
        </div>
    
    </div>



    <ul class="slides">
 
    <li style="background-image: url(http://www.carehospitals.com/uploads/banner_new10.jpg); background-color: rgb(196, 207, 209); display: none;">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image: url(http://www.carehospitals.com/uploads/banner_new6.jpg); background-color: rgb(197, 189, 186); display: none;">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image: url(http://www.carehospitals.com/uploads/banner_new3.jpg); background-color: rgb(143, 197, 215); display: list-item;">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/banner6.jpg); background-color:#e9a95f">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/New_banner-1.jpg); background-color:#3a6d9b">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/banner_new9.jpg); background-color:#e6f2e8">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/banner_new5.jpg); background-color:#518a9d">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/banner8.jpg); background-color:#b8b888">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/banner11.jpg); background-color:#adaaaa">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>
 
    <li style="background-image:url(http://www.carehospitals.com/uploads/banner-14.jpg); background-color:#bf9146">
    <div class="banner-center">
    <div class="banner-heading-main">
    <div class="banner-heading">
            <br><span></span>
      </div>
    </div>
    </div>
    </li>


</ul>
<ul class="slide-navs" style="margin-left: -512px;"><li class="slide-nav-0"><a></a></li><li class="slide-nav-1"><a></a></li><li class="slide-nav-2 current-slide"><a></a></li><li class="slide-nav-3"><a></a></li><li class="slide-nav-4"><a></a></li><li class="slide-nav-5"><a></a></li><li class="slide-nav-6"><a></a></li><li class="slide-nav-7"><a></a></li><li class="slide-nav-8"><a></a></li><li class="slide-nav-9"><a></a></li></ul><a class="prev"></a><a class="next"></a><a class="play-control pause" style="display: none;"></a></div>
</div>
<!-- banner End -->





<div class="welcome-note-main">
<div class="specialties-main">
	<div class="specialties">
    	<div class="table">
        	<div class="row">
            	<div class="cell specialties-heading">Specialties</div>
                <div class="cell specialties-list">
             
                <div class="marquee0" style="overflow: hidden;"><div style="visibility: visible; padding: 5px; top: -10px; width: 100%; height: 27px; position: relative; overflow: hidden;"><div style="position: absolute; left: -5092px; white-space: nowrap; top: -3px;">&nbsp;<ul style="padding-right:250px;">
                                        <li><span>Anesthesiology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-cardiacsciences">Cardiac Sciences</a></li>
                                                            <li><span>Clinical Psychology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-criticalcare">Critical Care</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-dentistry">Dentistry</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-dermatology">Dermatology</a></li>
                                                            <li><span>Dietetics &amp;  Nutrition</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-emergencymedicine">Emergency Medicine</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-endocrinology">Endocrinology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-ent">ENT</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-gastroenterology">Gastroenterology</a></li>
                                                            <li><span>General Medicine</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-generalsurgerysurgicalgastroenterology">General Surgery &amp; Surgical Gastroenterology</a></li>
                                                            <li><span>Hematology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-HepatoBiliarySurgeryandLiverTransplantation">Hepato Biliary Surgery &amp; Liver Transplantation</a></li>
                                                            <li><span>Infectious Disease</span></li>
                                                            <li><span>Lab Medicine (Biochemistry, Pathology, Microbiology)</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-laparoscopicbariatricsurgery">Laparoscopic &amp; Bariatric Surgery</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-nephrology">Nephrology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-neurosciences">Neuro Sciences</a></li>
                                                            <li><span>Nuclear Medicine</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-obstetricsgynecology">Obstetrics &amp; Gynecology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-oncology">Oncology</a></li>
                                                            <li><span>Oncology (Medical)</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-ophthalmology">Ophthalmology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-orthopedics">Orthopedics</a></li>
                                                            <li><span>Pediatric  Cardiology</span></li>
                                                            <li><span>Pediatric Cardiothoracic Surgery</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-pediatrics">Pediatrics</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-physiotherapyrehabilitation">Physiotherapy &amp; Rehabilitation</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-plasticsurgery">Plastic Surgery</a></li>
                                                            <li><span>Psychiatry</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-pulmonology">Pulmonology</a></li>
                                                            <li><span>Radiology</span></li>
                                                            <li><span>Rheumatology</span></li>
                                                            <li><span>Robotic Surgery</span></li>
                                                            <li><span>Surgical Oncology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-urology">Urology</a></li>
                                                            <li><span>Vascular Surgery</span></li>
                                                            <li><span>Wellness</span></li>
                                                            <li><span>Yoga Therapy</span></li>
                                                                
                    </ul></div><div style="position: absolute; left: 2126px; white-space: nowrap; top: -3px;">&nbsp;<ul style="padding-right:250px;">
                                        <li><span>Anesthesiology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-cardiacsciences">Cardiac Sciences</a></li>
                                                            <li><span>Clinical Psychology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-criticalcare">Critical Care</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-dentistry">Dentistry</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-dermatology">Dermatology</a></li>
                                                            <li><span>Dietetics &amp;  Nutrition</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-emergencymedicine">Emergency Medicine</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-endocrinology">Endocrinology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-ent">ENT</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-gastroenterology">Gastroenterology</a></li>
                                                            <li><span>General Medicine</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-generalsurgerysurgicalgastroenterology">General Surgery &amp; Surgical Gastroenterology</a></li>
                                                            <li><span>Hematology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-HepatoBiliarySurgeryandLiverTransplantation">Hepato Biliary Surgery &amp; Liver Transplantation</a></li>
                                                            <li><span>Infectious Disease</span></li>
                                                            <li><span>Lab Medicine (Biochemistry, Pathology, Microbiology)</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-laparoscopicbariatricsurgery">Laparoscopic &amp; Bariatric Surgery</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-nephrology">Nephrology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-neurosciences">Neuro Sciences</a></li>
                                                            <li><span>Nuclear Medicine</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-obstetricsgynecology">Obstetrics &amp; Gynecology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-oncology">Oncology</a></li>
                                                            <li><span>Oncology (Medical)</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-ophthalmology">Ophthalmology</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-orthopedics">Orthopedics</a></li>
                                                            <li><span>Pediatric  Cardiology</span></li>
                                                            <li><span>Pediatric Cardiothoracic Surgery</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-pediatrics">Pediatrics</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-physiotherapyrehabilitation">Physiotherapy &amp; Rehabilitation</a></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-plasticsurgery">Plastic Surgery</a></li>
                                                            <li><span>Psychiatry</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-pulmonology">Pulmonology</a></li>
                                                            <li><span>Radiology</span></li>
                                                            <li><span>Rheumatology</span></li>
                                                            <li><span>Robotic Surgery</span></li>
                                                            <li><span>Surgical Oncology</span></li>
                                                            <li><a href="http://www.carehospitals.com/specialty-urology">Urology</a></li>
                                                            <li><span>Vascular Surgery</span></li>
                                                            <li><span>Wellness</span></li>
                                                            <li><span>Yoga Therapy</span></li>
                                                                
                    </ul></div></div></div>
                    
                    

                  <!-- </marquee> -->
                </div>
            </div>
        </div>
    </div>

</div>
	<h1>Welcome to CARE Hospitals</h1>
    <p>
        The CARE Hospitals Group is a multispecialty healthcare 
provider, with 14 hospitals serving 6 cities across 5 states of India. 
The regional leader in tertiary care in South/Central India and among 
the top 4 pan-Indian hospital chains, CARE Hospitals delivers 
comprehensive care in more than 30 specialties in tertiary care 
settings...<span class="more-link"><a href="http://www.carehospitals.com/article-aboutus">More &gt;&gt;</a></span></p>
</div>
<style>
    .content-mainso { padding: 10px 10px 5px 10px;
                      margin-top:-8px;
background-image: url(images/bg_second.png); 
background-repeat: no-repeat;
min-height: 192px; }
    .content-mainso img { text-align: center;padding-left:10px;padding-top:25px; }
    .content-mainso p { padding-left:10px;font-size:13px;color: #006836; margin-top:0px; padding-top:0px; }
    .content-mainso p span { color: #006836;font-weight: 700; }
</style>
<div class="home-sections-1-main">
	<div class="home-sections-1">
    	<div class="home-sections-1-left">
            
<!--                <div class="coloum">
                    <div class="content-mainso">
                    <h2>&nbsp;</h2>
                    <img src="http://www.carehospitals.com/images/caresecond.png"  height="103" alt="CARE Second Opinion" title="CARE Second Opinion">
                    <p>An <span>honest</span> opinion to help you make the right choice</p>     
                    </div>
                    <div class="bg"></div>
                </div>-->
            
        	<div class="coloum">
            	<div class="content-main">
                	<h2>Updates</h2>
                    <ul>
                    	<li><a href="http://www.carehospitals.com/news_article">News@CARE</a>
                        
                        </li>
                        <li><a href="http://www.carehospitals.com/care-news">CARE in Media</a>
                        
                        </li>
                        <li><a href="http://www.carehospitals.com/care-announcements">Announcements</a>
                 <!--       	<marquee scrollamount="2" behavior="scroll" direction="up" onMouseOver="this.stop();" onMouseOut="this.start();" height="75px" style="margin-top:10px;">
                  		<ul class="scroll">
                                           	    <li><a href="http://www.carehospitals.com/care-announcements"></a></li>
                       
                                                </ul>
                  	    </marquee>
                      -->  
                        </li>
                        
                        
                  </ul>

                </div>
                <div class="bg"></div>
            </div>
            
          <div class="coloum">
            	<div class="content-main">
                	<h2>Patient Experiences</h2>
                                        <ul>
                   	  <li style=" letter-spacing:0px;">Dr Tom Cherian always spoke to me with a smile. </li>
                    </ul>
                    <div class="relative">
                    	<div class="patient-experiences-play"><a href="http://www.carehospitals.com/patient-experiences"><img src="<?php appsConfig::URL('apps/images/play.png')?>" alt="Patient Experiences" title="Patient Experiences" width="24" height="16"></a></div>
                  </div>
                    <a href="http://www.carehospitals.com/patient-experiences"><img src="<?php appsConfig::URL('apps/images/Nagamani.png')?>" alt="Mrs. G Nagamani Speaks of Her Liver Surgery at CARE Hospitals, Hyderabad" title="Mrs. G Nagamani Speaks of Her Liver Surgery at CARE Hospitals, Hyderabad" width="168" height="90"></a>
                    
                </div>
                <div class="bg"></div>
            </div>
            
            <div class="coloum">
            	<div class="content-main">
                	<h2>Education &amp; Training</h2>
                     <ul>
                   	  <li><a href="#">Education</a></li>
                        <li><a href="#">Training</a></li>
                  </ul>
              </div>
                <div class="bg"></div>
            </div>
            
            <div class="coloum last">
           	  <div class="content-main">
               	<h2>CARE Emergency</h2>
               <marquee scrollamount="2" behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();" style="margin-top:10px;" height="115px">
                  <ul>					  <li><a href="#">CARE Hospitals<br>Banjara Hills<br> Hyderabad<br>105711</a></li>
									  <li><a href="#">CARE Outpatient Centre<br>Banjara Hills<br>Hyderabad<br>105711</a></li>
									  <li><a href="#">CARE Hospitals<br>Nampally<br>Hyderabad<br>+91-40-30417777</a></li>
									  <li><a href="#">Guru Nanak CARE Hospitals<br>Musheerabad<br>Hyderabad<br>+91 40 30219000/9111/9123</a></li>
									  <li><a href="#">CARE Hospitals<br>Market Street<br>Secunderabad<br>+91 40 30114500</a></li>
									  <li><a href="#">CARE Hospitals<br>Hi-tech City<br>Hyderabad<br>040-33623500 / 3999</a></li>
									  <li><a href="#">CARE Hospitals<br>Ramnagar<br>Visakhapatnam<br>+91 891 2522622</a></li>
									  <li><a href="#">CARE Hospitals<br>Maharanipeta<br>Visakhapatnam<br>+91 891 3067044 / 22</a></li>
									  <li><a href="#">CARE Hospitals<br>Railway New Colony<br>Visakhapatnam<br>+91-0891-2554811</a></li>
									  <li><a href="#">Ramkrishna CARE Hospitals<br>Raipur<br>+91 771 3003364 /457/364</a></li>
									  <li><a href="#"> Aditya CARE Hospitals<br>Bhubaneswar<br>+91 9937299112</a></li>
									  <li><a href="#">CARE Hospitals<br>Prachi Enclave<br>Bhubaneswar<br>7077711777</a></li>
									  <li><a href="#">CARE Hospitals<br>Nagpur<br>+91 9423623456</a></li>
									  <li><a href="#">Galaxy CARE Hospitals<br>Pune<br>+91 20 30244100 / 2 / 3</a></li>
				                   	 
                  </ul>
                  </marquee>
                </div>
                <div class="bg"></div>
            </div>
            
        </div>
        
        
        <!-- Foundation -->
      <div class="care-foundation">
        	<h2>CARE Foundation</h2>
           <a href="http://www.carefoundation.org.in/" target="_blank"><img src="<?php appsConfig::URL('apps/images/foundation-img.png')?>" alt="CARE Foundation" title="CARE Foundation" width="121" height="103"></a></div>
    </div>
</div>
<!-- Container End -->
<!-- footer Start -->

<div style=" margin: 0px; padding: 0px; height: 0px; overflow: hidden;">
<!-- Google Code for Remarketing Tag -->

<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 956667694;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="Care%20Hospitals%20-%20Multispecialty%20Healthcare%20Centers%20in%20India_files/conversion.js">
</script><iframe name="google_conversion_frame" title="Google conversion frame" src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/956667694/?random=1495184235245&amp;cv=8&amp;fst=1495184235245&amp;num=1&amp;fmt=1&amp;guid=ON&amp;u_h=768&amp;u_w=1366&amp;u_ah=728&amp;u_aw=1366&amp;u_cd=24&amp;u_his=3&amp;u_tz=360&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;frm=0&amp;url=http%3A%2F%2Fwww.carehospitals.com%2F&amp;tiba=Care%20Hospitals%20-%20Multispecialty%20Healthcare%20Centers%20in%20India" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" width="300" height="13" frameborder="0"></iframe>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" 
src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/956667694/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
</div>

<script>            
    jQuery(document).ready(function() {
        var offset = 220;
        var duration = 500;
        jQuery(window).scroll(function() {
            if (jQuery(this).scrollTop() > offset) {
                jQuery('.back-to-top').fadeIn(duration);
            } else {
                jQuery('.back-to-top').fadeOut(duration);
            }
        });
        
        jQuery('.back-to-top').click(function(event) {
            event.preventDefault();
            jQuery('html, body').animate({scrollTop: 0}, duration);
            return false;
        })
    });
</script>


<!-- Footer End -->

</div>
<!--</div>-->
